'use strict';
var Alexa = require('alexa-sdk');
// var http = require('http');

var APP_ID = undefined;

//CONSTANTS
var letterNotPresent = 'I\'m sorry, that letter is not in there';
var letterPresent = 'Good, that letter is in there';
var letterOnePreset = 'There is a %s in spot %s';
var letterPresentMoreThanOne = 'There is a %s at the following spots:';


exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
	'NewSession': function() {
		this.handler.state = states.STARTMODE;
	},
    'LaunchRequest': function () {
        this.emit('NewSession');
    },
    'CheckLetterIntent': function () {
    	var letterGuess = this.event.request.intent.slots.letter.value;
        startGame();
        var indices = checkLetter(letterGuess);
        var output = '';
        if (indices.length === 0) {
        	output = 
        	this.emit(':tell', letterNotPresent, letterNotPresent);
        } else {
        	this.emit(':tell', letterPresent, letterPresent);
        }
    },
    'CheckGuessIntent': function () {
        this.emit(':tell', 'Hello World!');
    },
    'SessionEndedRequest': function () {
        this.emit('AMAZON.StopIntent');
    }
};

var randomWord = 'potato';
var lettersTried = [];
var guessedSoFar;


function startGame(){
	guessedSoFar = new Array(randomWord.length);
});

//get locations in the word where the given letter appears
function getIndexesOfLetterInWord(letter) {
	var indexes = [];
	for (var i = 0; i < randomWord.length; i++){
		if (letter == randomWord.charAt(i)){
			indexes.push(i);
			guessedSoFar[i] = letter;
		}
	}
	return indexes;
}

//add letters to array of tried letters
function addTriedLetter(letter) {
	lettersTried.push(letter);
	
}

//check if letter is in word and return indices
function checkLetter(letter) {
	var indexes = getIndexesOfLetterInWord(letter);
	if (lettersTried.indexOf(letter) === -1) {
		addTriedLetter(letter);
	}
	console.log('current word - ' + guessedSoFar);
	return indexes;
}

//returns if guess matches the random word
function checkGuessWord(word) {
	if (randomWord === word) {
		return true;
	} else {
		return false;
	}
}

//returns if all letters in array match random word
function checkAllLettersGuessed() {
	return checkGuessWord(guessedSoFar.join(''));
}




//TODO - get random word from internet
// http.get('http://randomword.setgetgo.com/get.php', function(res) {
// 	var randomWord = res;
// 	console.log(randomWord);
// }, function(err) {
// 	console.log('error', err);
// });

